async function send(msg) { return await chrome.runtime.sendMessage(msg); }

async function load() {
  const { apiKey } = await send({ type: "GET_KEY" });
  const { settings } = await send({ type: "GET_SETTINGS" });
  
  document.getElementById("apiKey").value = apiKey || "";
  document.getElementById("requireApproval").checked = !!settings.requireApproval;
  document.getElementById("includePageText").checked = !!settings.includePageText;
  document.getElementById("model").value = settings.model || "gpt-4o-mini";
  document.getElementById("maxContextChars").value = settings.maxContextChars ?? 5000;
}

async function save() {
  const apiKey = document.getElementById("apiKey").value.trim();
  const modelValue = document.getElementById("model").value.trim();
  
  if (!modelValue) {
    alert("Please enter a model ID");
    return;
  }
  
  const settings = {
    requireApproval: document.getElementById("requireApproval").checked,
    includePageText: document.getElementById("includePageText").checked,
    model: modelValue,
    maxContextChars: Number(document.getElementById("maxContextChars").value) || 5000,
  };
  
  await send({ type: "SAVE_KEY", apiKey });
  await send({ type: "SAVE_SETTINGS", settings });
  
  alert("Saved!");
}

async function run() {
  const apiKey = document.getElementById("apiKey").value.trim();
  const prompt = document.getElementById("prompt").value.trim();
  const modelValue = document.getElementById("model").value.trim();
  
  if (!apiKey) {
    alert("Please enter your OpenRouter API key");
    return;
  }
  
  if (!modelValue) {
    alert("Please enter a model ID");
    return;
  }
  
  if (!prompt) {
    alert("Please enter a prompt");
    return;
  }
  
  // Save current settings first
  await save();
  
  // Run on active tab
  const result = await send({ type: "RUN_ON_ACTIVE_TAB", prompt });
  
  if (result.error) {
    alert("Error: " + result.error);
  } else {
    window.close();
  }
}

document.getElementById("save").addEventListener("click", save);
document.getElementById("run").addEventListener("click", run);

load();
