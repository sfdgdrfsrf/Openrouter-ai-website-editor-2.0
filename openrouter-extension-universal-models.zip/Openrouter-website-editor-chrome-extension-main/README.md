# OpenRouter Control (MV3) - Universal Model Edition

OpenRouter-powered Chrome extension that edits pages, runs code in a sandbox, grabs screenshots, and moves text around — all from your prompt. No local file saves; outputs open in new tabs or POST to your webhook.

## ✨ Key Features

### 🚀 Universal Model Support
- **Use ANY OpenRouter model** - simply type the model ID!
- Built-in model browser with search and filtering
- Fetch and browse all available OpenRouter models in real-time
- Auto-complete suggestions as you type
- Popular models include:
  - `gpt-4o-mini` (default - fast and affordable)
  - `gpt-4o` (most capable GPT-4)
  - `anthropic/claude-3.5-sonnet` (Claude Sonnet)
  - `anthropic/claude-3-opus` (Claude Opus)
  - `google/gemini-pro` (Google's Gemini)
  - `meta-llama/llama-3.1-70b-instruct` (Meta Llama)
  - `deepseek/deepseek-chat` (DeepSeek)
  - `mistralai/mistral-large` (Mistral Large)

### 🛠️ Powerful Editing Features
- Prompt-driven page edits with preview/approval
- DOM tools: insert/delete/replace, style tweaks, attributes, find/replace text, scroll, click, set input values
- Files without downloads: open content in a new tab (data URL) or POST to your webhook
- Sandbox runner: execute HTML/CSS/JS in a sandboxed iframe overlay
- Screenshots: full page (visible area) or element crop → open in new tab
- Clipboard write, localStorage set/remove, open URL in new tab, extract text to "virtual file"

## Install (Dev)
1. Clone or download this repo
2. Open `chrome://extensions` in Chrome
3. Enable **Developer mode** (toggle in top right)
4. Click **Load unpacked** → select the repo folder
5. Pin the extension to your toolbar

## Setup

### 1. Get your OpenRouter API Key
- Visit [openrouter.ai/keys](https://openrouter.ai/keys)
- Sign up or log in
- Create a new API key
- Copy the key (starts with `sk-or-v1-`)

### 2. Configure the Extension
- Click the extension icon in your toolbar
- Paste your OpenRouter API key
- **Choose your model**:
  - Type any OpenRouter model ID directly, OR
  - Click "Options" → "Browse Available Models" to see all options
  - Search and filter through hundreds of models
  - Click on any model to select it

### 3. Configure File Handling (Optional)
In the Options page, you can set:
- **Open in new tab** (default) - Opens generated files in a new browser tab
- **POST to webhook** - Sends file content to your webhook endpoint
- **Ignore file outputs** - Skip file creation actions

### 4. Optional Settings
- **Require approval**: Preview changes before applying (recommended)
- **Include page text**: Send page content as context to the model
- **Max context chars**: Limit how much page text to send (default: 5000)

## Usage

### Method 1: Extension Popup
1. Navigate to any webpage
2. Optionally select text on the page
3. Click the extension icon
4. Type your prompt (e.g., "Make the text larger and center it")
5. Click **Run**
6. Review and approve the changes (if approval is enabled)

### Method 2: Right-Click Menu
1. Select text on any webpage
2. Right-click the selection
3. Choose **"OpenRouter: Use selection"**
4. The extension will analyze and modify based on your selection

## Example Prompts

Get creative! Here are some ideas:

### Content Editing
- "Rewrite the selected paragraph to be more professional"
- "Translate all headings to Spanish"
- "Summarize this article in bullet points and add it to the top of the page"

### Visual Changes
- "Make all images 50% larger"
- "Add a dark mode toggle button in the top-right corner"
- "Center all headings and make them bold"
- "Change the background color to a soft gradient"

### Data Extraction
- "Extract all email addresses and save them to a file"
- "Get all product prices from this page and create a CSV"
- "List all links on the page in a text file"

### Advanced Automation
- "Screenshot the main content area and save it"
- "Fill out this form with test data"
- "Click the 'Load More' button 5 times"
- "Run this HTML+CSS+JS code in a sandbox preview"

### Combining Actions
- "Find 'lorem ipsum' and replace with real text, then screenshot the result"
- "Extract all h2 headings to a file, then add a table of contents at the top"
- "Rewrite the article summary, add it to localStorage, and copy it to clipboard"

## Actions Schema (Model Output)

The extension expects strict JSON from the model with this structure:

```json
{
  "explain": "Brief description of what will be done",
  "actions": [
    { "type": "replaceSelection", "text": "new text here" },
    { "type": "insert", "selector": ".container", "html": "<div>content</div>", "position": "beforeend" },
    { "type": "delete", "selector": ".ad-banner" },
    { "type": "setStyle", "selector": "h1", "style": "color: blue; font-size: 48px;" },
    { "type": "createFile", "filename": "data.txt", "mime": "text/plain", "content": "file contents" },
    { "type": "clipboardWrite", "text": "text to copy" },
    { "type": "click", "selector": "#submit-button" },
    { "type": "setValue", "selector": "#email-input", "value": "test@example.com" },
    { "type": "replaceHTML", "selector": ".content", "html": "<p>new html</p>" },
    { "type": "addGlobalStyle", "css": "body { font-family: Arial; }" },
    { "type": "setAttribute", "selector": "img", "name": "loading", "value": "lazy" },
    { "type": "removeAttribute", "selector": "a", "name": "target" },
    { "type": "replaceText", "find": "old text", "replace": "new text", "exact": true },
    { "type": "scrollTo", "selector": "#target-section", "behavior": "smooth" },
    { "type": "screenshot", "selector": ".hero", "filename": "screenshot.png" },
    { "type": "openTab", "url": "https://example.com" },
    { "type": "localStorageSet", "key": "theme", "value": "dark" },
    { "type": "localStorageRemove", "key": "old-setting" },
    { "type": "extractToFile", "selector": ".article p", "filename": "article.txt", "mime": "text/plain" },
    { "type": "runSandbox", "html": "<h1>Demo</h1>", "css": "h1{color:red}", "js": "console.log('test')", "height": "420px" }
  ]
}
```

### Action Types Explained

**Content Manipulation:**
- `replaceSelection` - Replace currently selected text
- `insert` - Insert HTML at specified position (beforebegin/afterbegin/beforeend/afterend)
- `delete` - Remove elements matching selector
- `replaceHTML` - Replace inner HTML of elements
- `replaceText` - Find and replace text in the page

**Styling:**
- `setStyle` - Add inline CSS styles to elements
- `addGlobalStyle` - Add a global CSS block
- `setAttribute` / `removeAttribute` - Modify element attributes

**Interaction:**
- `click` - Click elements
- `setValue` - Set form input values
- `scrollTo` - Scroll to element or coordinates

**File Operations:**
- `createFile` - Create a file (opens in tab or sends to webhook)
- `extractToFile` - Extract text from elements and save to file
- `screenshot` - Capture screenshot of element or visible area

**Data:**
- `clipboardWrite` - Copy text to clipboard
- `localStorageSet` / `localStorageRemove` - Manage localStorage

**Advanced:**
- `runSandbox` - Execute HTML/CSS/JS in a sandboxed iframe
- `openTab` - Open a new browser tab

## Settings Reference

### Popup Settings (Quick Access)
- **API Key** - Your OpenRouter API key
- **Model** - Any OpenRouter model ID
- **Require approval** - Preview before applying changes
- **Include page text** - Send page content as context
- **Max context chars** - Limit context size

### Options Page Settings (Advanced)
Access via: Right-click extension icon → Options

- **Default Model** - Set your preferred default model
- **Browse Models** - Fetch and search all available models
- **File Output Mode**:
  - Open in new tab (data URL)
  - POST to webhook
  - Ignore file creation
- **Webhook URL** - Your webhook endpoint (if using webhook mode)

## Permissions Explained

- **storage** - Save API key and settings locally
- **scripting, activeTab, tabs** - Inject content script and interact with pages
- **clipboardWrite** - Copy text to clipboard when requested
- **contextMenus** - Add right-click menu option
- **host_permissions** (`<all_urls>`) - Work on any website

**Note:** No downloads permission — nothing writes to your disk. Files open in new tabs or POST to your webhook.

## Privacy & Security

- ✅ API key stored locally in `chrome.storage.local` (never transmitted except to OpenRouter)
- ✅ Requests go directly to OpenRouter with your key
- ✅ Page text only sent when "Include page text" is enabled (truncated by max chars)
- ✅ Webhook mode only POSTs to the URL you configure
- ✅ No telemetry, tracking, or third-party services
- ✅ Open source - audit the code yourself

## Developer Notes

### Architecture
- **Manifest V3** - Latest Chrome extension format
- **background.js** - Service worker handling API calls
- **popup.html/js** - Quick access popup UI
- **options.html/js** - Full settings page with model browser
- **content.js** - Injected script for page manipulation
- **Icons** - icon16.png, icon32.png, icon128.png

### Adding Custom Actions
To add new action types:
1. Add the action schema to the system prompt in `background.js`
2. Implement the action handler in `content.js` (applyActions function)
3. Add UI preview in `renderActionsSummary` if needed

### Model Selection System
The universal model support works by:
1. Accepting any text input as a model ID
2. Fetching available models from OpenRouter's `/api/v1/models` endpoint
3. Providing autocomplete suggestions based on fetched models
4. Passing the model ID directly to OpenRouter's API

### Extending File Handling
Current modes: open-tab, webhook, ignore

To add a new mode:
1. Add option in `options.html` file mode dropdown
2. Update `handleFileOutput` in `content.js`
3. Add corresponding handler in `background.js` if needed

## Known Quirks & Limitations

- ⚠️ Some sites block injection or iframe overlays due to strict CSP (Content Security Policy)
- ⚠️ Screenshots use `captureVisibleTab` - only visible portion is captured
- ⚠️ Very long outputs as data URLs may be slow to render
- ⚠️ `runSandbox` uses sandboxed iframes with no cross-origin access (by design)
- ⚠️ Model availability depends on your OpenRouter account tier and credits

## Troubleshooting

### "No API key" error
- Make sure you've pasted your OpenRouter API key in the popup
- Verify the key starts with `sk-or-v1-`
- Check that you've clicked "Save"

### "Invalid model" error
- Verify the model ID is correct (check [openrouter.ai/models](https://openrouter.ai/models))
- Some models require special access or credits
- Try using `gpt-4o-mini` as a fallback

### Changes not applying
- Check if "Require approval" is enabled - you need to click "Apply"
- Some sites have Content Security Policies that block modifications
- Try refreshing the page and running the extension again

### Model browser not loading
- Check your internet connection
- The browser fetches from `https://openrouter.ai/api/v1/models`
- Try clicking "Browse Available Models" again

## Roadmap

- [x] Universal model support (free-typed model ID) ✅
- [x] Model browser with search and filtering ✅
- [ ] Side panel with diffs and one-click undo
- [ ] Streaming responses and step-by-step apply
- [ ] Element picker (hover/select instead of typing selectors)
- [ ] Zip multiple "virtual files" into one data URL tab
- [ ] Model cost tracking and usage analytics
- [ ] Preset prompt library
- [ ] Undo/redo stack for changes
- [ ] Export/import configuration

## Contributing

Contributions welcome! This is an open-source project.

To contribute:
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

MIT License - Use freely, modify as needed, no warranty provided.

---

**Built with ❤️ and ☕**

OpenRouter Control makes AI-powered web editing accessible to everyone. Use responsibly and have fun!

For support and updates, visit: [openrouter.ai](https://openrouter.ai)
