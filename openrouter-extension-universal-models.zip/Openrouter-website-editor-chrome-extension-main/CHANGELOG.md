# Changelog - Universal Model Support Update

## Version 0.2.0 - Universal Model Edition

### 🎉 Major Features Added

#### Universal Model Support
- **ANY OpenRouter model** can now be used - just type the model ID!
- Removed hardcoded model dropdown restrictions
- Text input allows complete flexibility in model selection

#### Model Browser
- New "Browse Available Models" button in Options page
- Fetches all available models from OpenRouter API in real-time
- Search and filter through hundreds of models
- Click to select any model instantly
- Shows model names, descriptions, and pricing information
- Autocomplete suggestions as you type

#### Improved Default Settings
- Default model changed from `ai21/jamba-mini-1.7` to `gpt-4o-mini`
- Better out-of-box experience with a more popular, reliable model

### 🔧 Technical Changes

#### Files Modified
1. **popup.html**
   - Replaced model dropdown with text input
   - Added help text for entering model IDs
   - Cleaner, more flexible UI

2. **popup.js**
   - Updated to handle text input instead of dropdown
   - Added validation for model input

3. **options.html**
   - Replaced model dropdown with text input
   - Added model suggestions dropdown with autocomplete
   - Added "Browse Available Models" button
   - Added loading indicators
   - Added model fetching section with instructions
   - Improved styling for better UX

4. **options.js**
   - Complete rewrite with model fetching functionality
   - Added `fetchModels()` function to retrieve all OpenRouter models
   - Added `showModelSuggestions()` for autocomplete
   - Added click handlers for model selection
   - Implemented search/filter functionality
   - Added event listeners for input focus and blur

5. **background.js**
   - Updated DEFAULT_SETTINGS model to `gpt-4o-mini`
   - Added clarifying comment about universal model support

6. **README.md**
   - Comprehensive rewrite with universal model support details
   - Added examples of popular models
   - Added troubleshooting section
   - Improved documentation overall
   - Added setup instructions for model selection

### 🌟 Benefits

#### For Users
- No longer limited to pre-selected models
- Can use the latest models as soon as OpenRouter adds them
- Can use niche or specialized models for specific tasks
- Better control over cost vs. capability tradeoffs
- Easy discovery of new models

#### For Developers
- More maintainable codebase (no hardcoded model lists)
- Future-proof against new model releases
- Easier to add features without updating model lists
- Cleaner code separation

### 📝 Usage Changes

#### Before (Old Version)
```
1. Open popup
2. Select from dropdown (6 hardcoded options)
3. Limited to: gpt-4o-mini, gpt-4o, claude-3.5-sonnet, 
   mixtral, jamba-mini, deepseek-chat-free
```

#### After (New Version)
```
1. Open popup
2. Type ANY OpenRouter model ID
   Examples: 
   - gpt-4o-mini
   - anthropic/claude-3.5-sonnet
   - google/gemini-pro
   - meta-llama/llama-3.1-70b-instruct
   - Or click "Options" → "Browse Available Models"
3. Unlimited model selection
```

### 🎯 Popular Models You Can Now Use

The extension now supports ALL OpenRouter models including:

**OpenAI Models:**
- gpt-4o-mini (default)
- gpt-4o
- gpt-4-turbo
- gpt-3.5-turbo

**Anthropic Models:**
- anthropic/claude-3.5-sonnet
- anthropic/claude-3-opus
- anthropic/claude-3-sonnet
- anthropic/claude-3-haiku

**Google Models:**
- google/gemini-pro
- google/gemini-pro-vision
- google/gemini-flash

**Meta Models:**
- meta-llama/llama-3.1-405b-instruct
- meta-llama/llama-3.1-70b-instruct
- meta-llama/llama-3.1-8b-instruct

**DeepSeek Models:**
- deepseek/deepseek-chat
- deepseek/deepseek-chat-v3-0324:free

**Mistral Models:**
- mistralai/mistral-large
- mistralai/mixtral-8x7b-instruct
- mistralai/mistral-7b-instruct

**And many more!** Browse them all using the model browser feature.

### 🐛 Bug Fixes
- Fixed model selection persistence across sessions
- Improved error handling for invalid model IDs
- Better validation of user input

### 🔒 Security & Privacy
- No changes to security model
- Still 100% local storage of API keys
- No new permissions required
- No telemetry or tracking added

### ⚡ Performance
- Model fetching is optional (only when user clicks "Browse")
- Cached model list for faster subsequent searches
- No performance impact on regular usage

### 🔮 What's Next?
- Model cost tracking
- Usage analytics
- Favorite models list
- Recently used models
- Model recommendations based on task

### 💡 Tips for Using Universal Model Support

1. **Start with defaults:** `gpt-4o-mini` is fast and cheap
2. **Browse models:** Click "Browse Available Models" to see all options
3. **Search functionality:** Type to filter hundreds of models
4. **Check pricing:** Model browser shows cost per million tokens
5. **Try free models:** Many models have `:free` variants
6. **Read descriptions:** Each model has different strengths

### 📚 Additional Resources
- [OpenRouter Models List](https://openrouter.ai/models)
- [OpenRouter Documentation](https://openrouter.ai/docs)
- [Model Pricing](https://openrouter.ai/models#pricing)

---

## Migration Guide

### For Existing Users

Your existing settings will be preserved! The extension will automatically:
1. Keep your current model selection
2. Maintain all other settings (approval, context, etc.)
3. Work exactly as before, but with more options

If you want to explore new models:
1. Open the extension Options page
2. Click "Browse Available Models"
3. Search or scroll through the list
4. Click any model to select it
5. Click "Save"

### Testing Your Setup
1. Open the popup
2. Check that your model field shows a valid model ID
3. Try a simple prompt on any webpage
4. If it works, you're all set!

---

**Version:** 0.2.0  
**Release Date:** February 15, 2026  
**Update Type:** Major Feature Release  
**Breaking Changes:** None  
**Migration Required:** No
