# Quick Start Guide - Universal Model Support

## 🚀 Get Started in 3 Minutes

### Step 1: Install the Extension (30 seconds)
1. Open Chrome and go to `chrome://extensions`
2. Enable **Developer mode** (toggle in top-right)
3. Click **Load unpacked**
4. Select the extension folder
5. Pin the extension to your toolbar

### Step 2: Set Up Your API Key (1 minute)
1. Get your OpenRouter API key:
   - Visit [openrouter.ai/keys](https://openrouter.ai/keys)
   - Sign up or log in
   - Create a new key (free $0.50 credit for new users!)
   - Copy the key (starts with `sk-or-v1-`)

2. Configure the extension:
   - Click the extension icon
   - Paste your API key
   - Click **Save**

### Step 3: Choose Your Model (1.5 minutes)

#### Option A: Quick Start (Use Default)
The extension comes with `gpt-4o-mini` as default. You're ready to go!

#### Option B: Browse & Select (Recommended)
1. Click the extension icon
2. Click **Options** at the bottom
3. Click **"Browse Available Models"** button
4. Wait 2-3 seconds for models to load
5. Search or scroll through the list
6. Click any model to select it (try `anthropic/claude-3.5-sonnet`)
7. Click **Save**

#### Option C: Manual Entry (Advanced)
Just type any OpenRouter model ID in the Model field:
- `gpt-4o-mini` (fast, cheap, great default)
- `gpt-4o` (most capable GPT-4)
- `anthropic/claude-3.5-sonnet` (Claude Sonnet)
- `google/gemini-pro` (Google's Gemini)
- `meta-llama/llama-3.1-70b-instruct` (Meta Llama)

---

## 🎯 Your First Edit

Let's make a simple edit to test everything:

1. **Go to any webpage** (try Wikipedia or a news site)
2. **Select some text** on the page
3. **Click the extension icon**
4. **Type a prompt:** "Rewrite this text to be more casual and friendly"
5. **Click Run**
6. **Review and Apply** the changes

That's it! You just used AI to edit a webpage.

---

## 💡 Try These Prompts Next

### Beginner-Friendly
- "Make the font size larger"
- "Center all the headings"
- "Change the background color to light blue"
- "Hide all images on this page"

### Intermediate
- "Extract all email addresses and save them to a file"
- "Add a dark mode toggle button"
- "Create a table of contents from the headings"
- "Translate the main content to Spanish"

### Advanced
- "Screenshot the hero section and save it"
- "Find all product prices and create a CSV file"
- "Add a sticky note widget with task reminders"
- "Run this code in a sandbox: [your HTML/CSS/JS]"

---

## 🎨 Understanding Model Selection

### What's a Model?
A model is the AI that processes your prompts. Different models have different:
- **Capabilities** (some are smarter, some are faster)
- **Costs** (from free to $$$)
- **Speeds** (response time varies)
- **Specializations** (coding, writing, analysis, etc.)

### Popular Model Recommendations

#### For Most Tasks: `gpt-4o-mini`
- Fast responses
- Low cost (~$0.15 per million tokens)
- Good quality
- Default choice

#### For Complex Tasks: `gpt-4o`
- Highest quality
- Best reasoning
- More expensive (~$5 per million tokens)
- Use for difficult prompts

#### For Creative Writing: `anthropic/claude-3.5-sonnet`
- Excellent at writing
- Good reasoning
- Moderate cost (~$3 per million tokens)
- Great for content creation

#### For Coding: `anthropic/claude-3-opus`
- Best for code generation
- Strong at complex tasks
- Higher cost (~$15 per million tokens)
- Worth it for dev work

#### Free Options:
- `meta-llama/llama-3.1-8b-instruct:free`
- `google/gemini-flash-1.5:free`
- `deepseek/deepseek-chat-v3-0324:free`

---

## 🔍 Using the Model Browser

The built-in model browser helps you find the perfect model:

### How to Use:
1. Open **Options** page
2. Click **"Browse Available Models"**
3. Wait for models to load (2-3 seconds)

### Browsing Tips:
- **Search:** Type keywords to filter (e.g., "claude", "free", "coding")
- **Scroll:** Browse all available models
- **Click:** Select any model instantly
- **Info:** Each model shows name, description, and pricing

### What to Look For:
- **Model Name:** The ID you'll use
- **Description:** What it's good at
- **Pricing:** Cost per million tokens
- **Context Window:** How much text it can handle

---

## ⚙️ Settings Explained

### Popup Settings (Quick Access)
- **API Key:** Your OpenRouter key (required)
- **Model:** Which AI to use (now supports ANY model!)
- **Require approval:** Preview changes before applying (recommended: ON)
- **Include page text:** Send page content as context (recommended: ON)
- **Max context chars:** Limit text sent (5000 is good)

### Options Page Settings
- **Default Model:** Your preferred model
- **File Output Mode:** How to handle file creation
  - Open in tab (default - best for most users)
  - Webhook (for automation/integrations)
  - Ignore (disable file creation)
- **Webhook URL:** Your endpoint if using webhook mode

---

## 🐛 Troubleshooting

### "Error: No API key"
- You need to add your OpenRouter API key
- Click the extension icon → paste key → Save
- Get a key at [openrouter.ai/keys](https://openrouter.ai/keys)

### "Error: Invalid model"
- Double-check the model ID is correct
- Try using `gpt-4o-mini` as a test
- Use the model browser to see valid options

### Changes not appearing
- Make sure "Require approval" is enabled
- Click the **Apply** button when prompted
- Some websites block modifications (CSP restrictions)

### Model browser not loading
- Check your internet connection
- Click the button again
- Try refreshing the Options page

---

## 📊 Model Cost Comparison

Understanding costs helps you choose the right model:

| Model | Cost (per 1M tokens) | Speed | Quality | Best For |
|-------|---------------------|-------|---------|----------|
| gpt-4o-mini | $0.15 | ⚡️⚡️⚡️ | ⭐️⭐️⭐️ | Most tasks |
| gpt-4o | $5.00 | ⚡️⚡️ | ⭐️⭐️⭐️⭐️⭐️ | Complex work |
| claude-3.5-sonnet | $3.00 | ⚡️⚡️ | ⭐️⭐️⭐️⭐️ | Writing, analysis |
| gemini-pro | $0.50 | ⚡️⚡️⚡️ | ⭐️⭐️⭐️ | General use |
| llama-3.1-70b | $0.88 | ⚡️⚡️ | ⭐️⭐️⭐️ | Open source |
| deepseek-chat:free | $0.00 | ⚡️ | ⭐️⭐️ | Testing |

**Note:** Costs are approximate and may change. Check [openrouter.ai/models](https://openrouter.ai/models) for current pricing.

---

## 🎓 Learning Resources

### Official Documentation
- [OpenRouter Docs](https://openrouter.ai/docs) - API documentation
- [Model List](https://openrouter.ai/models) - All available models
- [Pricing](https://openrouter.ai/models#pricing) - Cost breakdown

### Extension Docs
- `README.md` - Full documentation
- `CHANGELOG.md` - What's new
- Action schema reference in README

### Community
- OpenRouter Discord - Get help and share ideas
- GitHub Issues - Report bugs or request features

---

## 🎉 You're Ready!

You now have:
- ✅ Extension installed
- ✅ API key configured
- ✅ Model selected (or using default)
- ✅ Understanding of basic usage

**Next steps:**
1. Open any webpage
2. Try editing something
3. Experiment with different prompts
4. Explore different models

Have fun with your AI-powered web editing! 🚀

---

**Pro Tips:**
- Start with simple prompts and build complexity
- Use "Require approval" until you're comfortable
- Try different models for different tasks
- Save your favorite prompts for reuse
- Check model costs if you're doing lots of edits

**Need help?** Check the README.md or visit [openrouter.ai/docs](https://openrouter.ai/docs)
