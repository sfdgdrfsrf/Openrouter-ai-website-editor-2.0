async function send(msg) { return await chrome.runtime.sendMessage(msg); }

let cachedModels = [];

async function load() {
  const { settings } = await send({ type: "GET_SETTINGS" });
  document.getElementById("requireApproval").checked = !!settings.requireApproval;
  document.getElementById("includePageText").checked = !!settings.includePageText;
  document.getElementById("model").value = settings.model || "gpt-4o-mini";
  document.getElementById("maxContextChars").value = settings.maxContextChars ?? 5000;
  document.getElementById("fileMode").value = settings.fileMode || "open-tab";
  document.getElementById("webhookUrl").value = settings.webhookUrl || "";
}

async function save() {
  const settings = {
    requireApproval: document.getElementById("requireApproval").checked,
    includePageText: document.getElementById("includePageText").checked,
    model: document.getElementById("model").value.trim(),
    maxContextChars: Number(document.getElementById("maxContextChars").value) || 5000,
    fileMode: document.getElementById("fileMode").value,
    webhookUrl: document.getElementById("webhookUrl").value.trim()
  };
  
  if (!settings.model) {
    alert("Please enter a model ID");
    return;
  }
  
  await send({ type: "SAVE_SETTINGS", settings });
  alert("Settings saved!");
}

async function fetchModels() {
  const fetchBtn = document.getElementById("fetchModels");
  const statusEl = document.getElementById("fetchStatus");
  const suggestionsEl = document.getElementById("modelSuggestions");
  
  fetchBtn.disabled = true;
  statusEl.textContent = "Fetching models...";
  
  try {
    const response = await fetch("https://openrouter.ai/api/v1/models");
    if (!response.ok) throw new Error("Failed to fetch models");
    
    const data = await response.json();
    cachedModels = data.data || [];
    
    statusEl.textContent = `Found ${cachedModels.length} models`;
    setTimeout(() => { statusEl.textContent = ""; }, 3000);
    
    // Show all models initially
    showModelSuggestions("");
    
  } catch (error) {
    statusEl.textContent = "Error fetching models";
    console.error("Error fetching models:", error);
    setTimeout(() => { statusEl.textContent = ""; }, 3000);
  } finally {
    fetchBtn.disabled = false;
  }
}

function showModelSuggestions(filter) {
  const suggestionsEl = document.getElementById("modelSuggestions");
  
  if (cachedModels.length === 0) {
    suggestionsEl.classList.remove("show");
    return;
  }
  
  const filterLower = filter.toLowerCase();
  let filtered = cachedModels;
  
  if (filter) {
    filtered = cachedModels.filter(model => 
      model.id.toLowerCase().includes(filterLower) ||
      (model.name && model.name.toLowerCase().includes(filterLower))
    );
  }
  
  // Limit to top 50 results
  filtered = filtered.slice(0, 50);
  
  if (filtered.length === 0) {
    suggestionsEl.classList.remove("show");
    return;
  }
  
  suggestionsEl.innerHTML = filtered.map(model => {
    const name = model.name || model.id;
    const desc = model.description || "";
    const pricing = model.pricing ? 
      `$${(model.pricing.prompt * 1000000).toFixed(4)}/M tokens` : 
      "";
    
    return `
      <div class="model-suggestion-item" data-model-id="${escapeHtml(model.id)}">
        <div class="model-name">${escapeHtml(model.id)}</div>
        <div class="model-desc">${escapeHtml(name)}${pricing ? " • " + pricing : ""}</div>
      </div>
    `;
  }).join("");
  
  // Add click handlers
  suggestionsEl.querySelectorAll(".model-suggestion-item").forEach(item => {
    item.addEventListener("click", () => {
      const modelId = item.getAttribute("data-model-id");
      document.getElementById("model").value = modelId;
      suggestionsEl.classList.remove("show");
    });
  });
  
  suggestionsEl.classList.add("show");
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// Event listeners
document.getElementById("save").addEventListener("click", save);
document.getElementById("fetchModels").addEventListener("click", fetchModels);

const modelInput = document.getElementById("model");
modelInput.addEventListener("input", (e) => {
  if (cachedModels.length > 0) {
    showModelSuggestions(e.target.value);
  }
});

modelInput.addEventListener("focus", () => {
  if (cachedModels.length > 0) {
    showModelSuggestions(modelInput.value);
  }
});

// Close suggestions when clicking outside
document.addEventListener("click", (e) => {
  const suggestionsEl = document.getElementById("modelSuggestions");
  if (!modelInput.contains(e.target) && !suggestionsEl.contains(e.target)) {
    suggestionsEl.classList.remove("show");
  }
});

load();
